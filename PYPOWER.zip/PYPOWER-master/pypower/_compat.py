
"""
Compatibility helpers for older Python versions.

"""
import sys


PY2 = sys.version_info[0] == 2
