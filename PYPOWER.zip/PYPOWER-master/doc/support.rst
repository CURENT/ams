Support
-------

Questions and comments regarding PYPOWER should be directed to the `mailing
list <http://groups.google.com/group/pypower>`_:

    pypower@googlegroups.com

Users may also wish to refer to the MATPOWER_ mailing list:

    http://www.mail-archive.com/matpower-l@list.cornell.edu/

Bugs and patches can be posted on the GitHub_ issue tracker:

    http://github.com/rwl/PYPOWER/issues

For all other enquiries please email:

    r.w.lincoln@gmail.com

.. include:: ./link_names.txt
